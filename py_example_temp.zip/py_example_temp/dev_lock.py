'''

Adapted excerpt from Getting Started with Raspberry Pi by Matt Richardson

Modified by Rui Santos
Complete project details: http://randomnerdtutorials.com

==========> Port Numbering Rule <===============
MON=1 TUE=2 WED=3 THU=4 FRI=5 SAT=SUN=0
ex) WED -> 38080,  SAT -> 8281, SUN -> 8788
------------------------------------------------
'''

_IP_ADDRESS_='192.168.1.11'
_PORT_NUMBER_=12345

import RPi.GPIO as GPIO
from flask import Flask, render_template, request

app = Flask(__name__)
GPIO.setmode(GPIO.BCM)

import time
import threading

min=60
hour=60*min
half=12*hour
day=24*hour

TIMER_MAX= 60*min #24*hour
TIMER_OUT=-1

TIMER_MAX_HMS=time.strftime("%H:%M:%S", time.gmtime(TIMER_MAX))
#TIMER_MAX_HMS=TIMER_MAX

# Create a dictionary called pins to store the pin number, name, and pin state:

# dictionary
pins = { 
   04 : {'name' : 'GPIO 04', 'state' : GPIO.LOW, 'alias':       'LIGHT', 'hmstimer': TIMER_MAX_HMS, 'timer': TIMER_MAX, 'percent': 100},

   17 : {'name' : 'GPIO 17', 'state' : GPIO.LOW, 'alias':     'LIGHT 2', 'hmstimer': TIMER_MAX_HMS, 'timer': TIMER_MAX, 'percent': 100},
   27 : {'name' : 'GPIO 27', 'state' : GPIO.LOW, 'alias':          'TV', 'hmstimer': TIMER_MAX_HMS, 'timer': TIMER_MAX, 'percent': 100},
   22 : {'name' : 'GPIO 22', 'state' : GPIO.LOW, 'alias':         'FAN', 'hmstimer': TIMER_MAX_HMS, 'timer': TIMER_MAX, 'percent': 100},


   18 : {'name' : 'GPIO 18', 'state' : GPIO.LOW, 'alias':      'HEATER', 'hmstimer': TIMER_MAX_HMS, 'timer': TIMER_MAX, 'percent': 100},

   23 : {'name' : 'GPIO 23', 'state' : GPIO.LOW, 'alias':    'DOORLOCK', 'hmstimer': TIMER_MAX_HMS, 'timer': TIMER_MAX, 'percent': 100},
   24 : {'name' : 'GPIO 24', 'state' : GPIO.LOW, 'alias':'ELECTRIC PAD', 'hmstimer': TIMER_MAX_HMS, 'timer': TIMER_MAX, 'percent': 100},

   25 : {'name' : 'GPIO 25', 'state' : GPIO.LOW, 'alias':       'ALIAS', 'hmstimer': TIMER_MAX_HMS, 'timer': TIMER_MAX, 'percent': 100}
   }


TIMER_DEVICE_MAX=[min, min, min, min, min, min, min, min]


#for pin in pins:
#	pins[pin]['timer']=TIMER_DEVICE[pin]


# Set each pin as an output and make it low:
for pin in pins:
   GPIO.setup(pin, GPIO.OUT)
   GPIO.output(pin, GPIO.LOW)



duplicate=0
recall_timing=10 #02 -> small=>time fast big=>time slow
ticksize=50      #50 -> small=>time slow big=>time fast
#============================================================
#============================================================
#============================================================
#============================================================

import threading 
import time

def TimeR(name, delay, repeat):
        print "Timer: " + name + " Started"
        tLock.acquire()
        print name + " has acquired the lock"
        while repeat > 0:
                time.sleep(delay)
                print name + ": " + str(time.ctime(time.time()))
                repeat -= 1
        print name + " is releasing the lock"
        tLock.release()
        print "Timer: " + name + " Completed"

#============================================================
#============================================================
#============================================================
#============================================================
#============================================================
def ActivatedDeviceReport():

   nActivated=0 
   """ tetrasys debug
   # 
   # Total Device Check 
   #      for debug message
   #----------------------------------------------------------------------------------     
   #for pin in pins:
   #   nActivated+=pins[pin]['state'] 
   #"""
   #-----------------------------------------------------------------------------------
   for pin in pins:  
      if GPIO.LOW < pins[pin]['state']: #or GPIO.LOW != pins[pin]['state']:
         nActivated+=pins[pin]['state']
         """
         message1 = "pin=["+str(pin)+"], state=["+str(pins[pin]['state'])
         message2 = "] device has activated. timer="+str(pins[pin]['timer'])+" remains"
         print message1 + message2
         #"""
      if TIMER_OUT >= pins[pin]['timer']:
         pins[pin]['timer']=TIMER_OUT
         GPIO.output(pin, GPIO.LOW) 
         #pins[pin]['state']=GPIO.LOW  
   #-----------------------------------------------------------------------------------
   """ tetrasys debug
   print "Activated Device #", nActivated

   return nActivated  
   #----------------------------------------------------------------------------------     
   #"""
#============================================================


#============================================================
def updateTimer(device):


	   ############################################ 
	   # tetra here is the 2nd Answer!!! good job!!
	   ############################################ 
	   if 0 == ActivatedDeviceReport():
	      GPIO.output(device, GPIO.LOW)
	      pins[device]['timer']=TIMER_OUT
	      #sys.exit() # <- fatal error !!! non exit!!
	      #

	   ############################################ 
	 
	   if TIMER_OUT > pins[device]['timer']:
	      pins[device]['timer']=TIMER_MAX
	      GPIO.output(device, GPIO.LOW)
	      """ tetrasys debug <-- comment must be indented
	      #  debug message block   
	      deviceName=pins[device]['name']
	      message = "Turned " + deviceName + " off."
	      print(message)
	      print device, "was shutdowned" 
	    
	   print(".:::::::Recall.Timing::::::::%d"%(recall_timing))+"::::sec.Cycle::::::::::."
	   print "recall device= ",device, " timer=", pins[device]['timer']
	   # tetrasys ----> debug message block
	   #"""
	 
	   #pins[device]['hmstimer']=time.strftime("[%d] %H:%M:%S", time.gmtime(pins[device]['timer']))
	   #pins[device]['hmstimer']=str(pins[device]['timer']/day)+"-"+time.strftime("%H:%M:%S", time.gmtime(pins[device]['timer']))
	   pins[device]['hmstimer']=time.strftime("%H:%M:%S", time.gmtime(pins[device]['timer']))
	   pins[device]['percent']=float(pins[device]['timer'])/float(TIMER_MAX)*100.0
	   """ tetrasys debug

	   print "Device:",device, "Countdown:", pins[device]['hmstimer'], "Progress=: ", pins[device]['percent']

	   #""" 

	   print "device=", device, "timer=", pins[device]['timer'],"ticksize=", ticksize 	
	   pins[device]['timer']=pins[device]['timer']-ticksize

	   #if pins[device]['timer'] >= pins[device]['timer']-ticksize:
	   #if 0 == duplicate:
	   #threading.Timer(recall_timing,updateTimer,[device]).start()  
	   t1=threading.Thread(target=TimeR, args("Timer1", device, recall_timing)) 
	   t1.start()
  
#========================================================================================================================


#========================================================================================================================
@app.route("/")
def main():

    # For each pin, read the pin state and store it in the pins dictionary:
    for pin in pins:
      pins[pin]['state'] = GPIO.input(pin)      

    # Put the pin dictionary into the template data dictionary:
    templateData = {
      'pins' : pins
      }

    # Pass the template data into the template main.html and return it to the user
    return render_template('main.html', **templateData)

#==================================================
#==================================================
#==================================================
#==================================================
#==================================================


# The function below is executed when someone requests a URL with the pin number and action in it:
@app.route("/<changePin>/<action>")
def action(changePin, action):

   """ tetrasys debug
   # 
   # Total Device Check 
   #      for debug message
   #----------------------------------------------------------------------------------     
   for pin in pins:  
      if GPIO.LOW < pins[pin]['state']: 
        message1 = "pin=["+str(pin)+"], state=["+str(pins[pin]['state'])
        message2 = "] device has activated. timer="+str(pins[pin]['timer'])+" remains"
        print message1 + message2
   #----------------------------------------------------------------------------------     
   #"""

   # Convert the pin from the URL into an integer:
   changePin = int(changePin)
   # Get the device name for the pin being changed:
   deviceName = pins[changePin]['name']
   deviceTimer = pins[changePin]['timer']#tetrasys
   # If the action part of the URL is "on," execute the code indented below:

   if TIMER_OUT >= pins[changePin]['timer']:
       pins[changePin]['timer']=TIMER_OUT
       pins[changePin]['state']=GPIO.LOW
   ######################################################
   # tetrasys here is the Answer!!! thread filtering part  
   ######################################################
   #if TIMER_MAX <= pins[changePin]['timer']:
   #    threading.Timer(recall_timing,updateTimer,[changePin]).start()

   prePin=changePin

   ##=============================================================
   ##=============================================================
   ##=============================================================
   if action == "on":
      # Set the pin HIGH:
      GPIO.output(changePin, GPIO.HIGH) 

      # TETRA 
      pins[changePin]['timer']=TIMER_MAX
      deviceTimer = pins[changePin]['timer']
 	  
      pins[changePin]['hmstimer']=time.strftime("%H:%M:%S", time.gmtime(pins[changePin]['timer']))
      pins[changePin]['percent']=float(pins[changePin]['timer'])/float(TIMER_MAX)*100.0
	  ######################################################
	  # tetrasys here is the Answer!!! thread filtering part  
	  ######################################################
      #if TIMER_MAX <= pins[changePin]['timer']:
      #if TIMER_MAX == pins[changePin]['timer']:
      #if (TIMER_MAX == pins[changePin]['timer']):
	  #   threading.Timer(recall_timing,updateTimer,[changePin]).start()
   
      #"""
      ti=threading.Timer(recall_timing,updateTimer,[changePin])
      if (TIMER_MAX == pins[changePin]['timer']):
	     ti.start()
      #"""

      #pt=PeriodicThread(recall_timing,updateTimer,changePin)
      #if (TIMER_MAX == pins[changePin]['timer']):
	  #   pt.start()

      """ tetrasys debug
      # Save the status message to be passed into the template:
      message = "Now Turned " + deviceName + " On, " + str(deviceTimer) + "sec. remains"
      print message
      #"""
   ##*************************************************************
   ##*************************************************************
   if action == "off":
      # Set the pin LOW:
      GPIO.output(changePin, GPIO.LOW)

      # TETRA
      pins[changePin]['timer']=TIMER_OUT
      deviceTimer = pins[changePin]['timer']


      """ tetrasys debug
      # Save the status message to be passed into the template:      
      message = "Now Turned " + deviceName + " Off, " + str(deviceTimer) + "sec. remains"
      print message
      #"""

      #t=threading.Timer(recall_timing,updateTimer,[changePin])
      rt=RepeatTimer(recall_timing,updateTimer,changePin)
      rt.stop()
      rt.terminate()

      """ 
      counter = 0
      while True:
		    try:
		        time.sleep(3) 
		        Nop()
		        counter = counter +1
		        print(counter)
		        if counter == 20:
		            print(t.getName)
		            t.cancel()
		            counter = 0
		            break
		        if t.is_alive() == False:
		            print("The Timer thread is dead...")
		    except KeyboardInterrupt:
		        print("End of program")
		        t.cancel()
		        system.exit(0)
		    except:
		        print("something wrong happens...")
      if t.is_alive() == True:
		    print("timer is alive...")
		    print(t.getName)
		    t.cancel()
      """
      #sys.exit()


      # tetrasys
      #pins[changePin]['timer']=0
   ##=============================================================
   ##=============================================================
   ##=============================================================



    
   # For each pin, read the pin state and store it in the pins dictionary:
   for pin in pins:
      pins[pin]['state'] = GPIO.input(pin)

   # Along with the pin dictionary, put the message into the template data dictionary:
   templateData = {
       'pins' : pins
   }

   return render_template('main.html', **templateData)  
   ##=============================================================
   ##=============================================================  
   ##=============================================================  
   ##=============================================================  
   ##=============================================================

if __name__ == "__main__":
   app.run(host=_IP_ADDRESS_, port=_PORT_NUMBER_, debug=True)

