import time

def example1():
    print 'Example'

def timer2():
    print 'timer2'

class Task(object):
    def __init__(self, func, delay, args=()):
        self.args = args
        self.function = func
        self.delay = delay
        self.next_run = time.time() + self.delay

    def shouldRun(self):
        return time.time() >= self.next_run

    def run(self):
        self.function(*(self.args))
        self.next_run += self.delay
        # self.next_run = time.time() + self.delay

#tasks = [Task(example1, 1)] # Run example1 every second
tasks = [Task(example1, 1), Task(timer2, 4)] # Run example1 every second
while True:
    for t in tasks:
        if t.shouldRun():
            t.run()
        time.sleep(0.01)
