
# Python program to find the factorial of a number provided by the user.
def factorial(number) :
	if 1 >= number :
		return 1
	else :
		return number*factorial(number-1)

import random

MAXNUM = 45

def lotto_numbers() :
	ballBox = {n for n in range(MAXNUM+1) if n>0}

	lotto = []
	#bonus = []

	i=0 # before pickup number
	choiceball=0 #randomball(ballBox)		
	ballBox.discard(choiceball)
	#print '#{:1} pick  ChoiceBall={:2}  TotalBall={:2}EA >>> BALLBOX...{:}'.format(i, choiceball, len(ballBox), ballBox)
    
	for i in range(1,7) :
		choiceball=randomball(ballBox)
		lotto.append(choiceball)
		ballBox.discard(choiceball)
	#	print '#{:1} pick  ChoiceBall={:2}  TotalBall={:2}EA >>> BALLBOX...{:}'.format(i, choiceball, len(ballBox), ballBox)
	lotto.sort()

	i=7 # last pickup bonus number
	choiceball=randomball(ballBox)	
	ballBox.discard(choiceball)
	#print '#{:1} pick **Bonus  ChoiceBall={:2}  TotalBall={:2}EA >>> BALLBOX...{:}'.format(i, choiceball, len(ballBox), ballBox)
	bonus=choiceball

	#print '{:} + {:2}'.format(lotto, bonus)
	lotto.append(bonus)
	return lotto


def randomball(ballBox) :
	#return random.randint(1,45)
	#return random.choice(list(enumerate(ballBox)))
	return random.choice(list(ballBox))

MAN=10000
LottoMax=0
LotteryMax=1000*MAN
# 
# 50*MAN About 7 min takes

if __name__ == '__main__':

	#lotto_matrix = {} # lotto Matrix dictionary create
	#lotto_matrix = [] 
	#lotto_matrix = [[x for x in range(LottoMax+1)] for y in range(LotteryMax+1)] # lotto Matrix 2D list create
	a = b = []
	winner = [2,10,20,30,35,40]

	No_1 = No_2 = No_3 = 0
	for j in range(LotteryMax) : # lottery Cycling to LotteryMax
		#a=lotto_matrix[j]=lotto_numbers()
		a = b =lotto_numbers()
		a = a[:6]

		contained = [x for x in winner if x in a]
		#contained = [x for x in winner if x not in a]
		#temp3 = tuple(x for x in temp1 if x not in set(temp2))

		if 3 < len(contained) <= 4 :
			print ' '*8+"4 CONTAINED"+3*' ', contained
		#	print '{:50}th LOTTO {:}'.format(j, b)
			No_3 += 1 
		elif 4 < len(contained) <= 5 :
			print ' '*7+"5 CONTAINED"+3*' ', contained
			print '{:50}th LOTTO {:}'.format(j, b)
			No_2 += 1 
		elif 6 == len(contained) :
			print '@'*10+"ALL MATCH"+10*'@', contained
			print '{:50}th LOTTO {:}'.format(j, b)
			No_1 += 1 
    
    print '\n'+40*'_'
    print '\n'+40*'_'
	print 'No.1(6):{:3} No.2(5):{:4} No.3(4):{:5}'.format(No_1, No_2, No_3)		
    print '\n'+40*'_'
    print '\n'+40*'_'

		"""
		if 3 < len(contained) < 5 :
			print ' '*8+"4 CONTAINED"+3*' ', contained
		#	print '{:50}th LOTTO {:}'.format(j, lotto_matrix[j])
		elif 4 < len(contained) < 6 :
			print ' '*7+"5 CONTAINED"+3*' ', contained
			print '{:50}th LOTTO {:}'.format(j, lotto_matrix[j])
		elif 6 == len(contained) :
			print '@'*10+"ALL MATCH"+10*'@', contained
			print '{:50}th LOTTO {:}'.format(j, lotto_matrix[j])
		#else :
		#	print "BOMB !!!"	
		"""


		"""
		if a.count(w[0]) and a.count(w[1]) and a.count(w[2]) and a.count(w[3]) and a.count(w[4]) and a.count(w[5]) :
			print "Found 6 number =>", a
			print '{:50}th LOTTO {:}'.format(j, lotto_matrix[j])
		"""

		#print '{:6}th Lottery Ticket [ {:2} {:2} {:2} {:2} {:2} {:2} + {:2} ]'       \
		#      .format(j+1, lotto_matrix[j][0],lotto_matrix[j][1],lotto_matrix[j][2], \
		#	               lotto_matrix[j][3],lotto_matrix[j][4],lotto_matrix[j][5], lotto_matrix[j][6] )

	shoot = random.randint(1,LotteryMax) # n-th lottery ticket random-shoot
	j = shoot-1 # real shoot -> matrix index mapping
	print '{:6}th Lottery Ticket [ {:2} {:2} {:2} {:2} {:2} {:2} + {:2} ]'       \
	      .format(j+1, lotto_matrix[j][0],lotto_matrix[j][1],lotto_matrix[j][2], \
		               lotto_matrix[j][3],lotto_matrix[j][4],lotto_matrix[j][5], lotto_matrix[j][6] )



	n = 45 
	k = 6
	nCk = factorial(n)/(factorial(k)*factorial(n-k))

	print 'COMBINATION: Lotto nCk... # of case=', nCk
	print 'PROBABILITY={:f}%'.format(100.*1./nCk)		


	"""		      
	stat = []
	for k in range(5) :
		stat.extend(lotto_numbers())
	"""	



	"""
	#print stat
	for i in range(1,46) : 
		print 'number={:2}  count={:4}'.format(i, stat.count(i))

	"""	
	"""
	a = []	
	for l in range(5) :
		a=lotto_numbers()
		if a.count(23) and a.count(27) and a.count(28) and a.count(38) and a.count(42) and a.count(43) :
			print "yes" 
	"""